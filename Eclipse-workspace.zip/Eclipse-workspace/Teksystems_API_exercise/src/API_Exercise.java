import java.lang.*;
import java.io.*;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

import org.json.JSONException;
import org.json.JSONObject;




public class API_Exercise {

	public static void main(String[] args) {
		

		try{
			Scanner scanner = new Scanner(System.in);
			
			System.out.println("Welcome to the country capital verification.");

     		System.out.println("Whose info do you want to get?");
			System.out.println("(Type the name now.)");
			String name = scanner.nextLine();
			
			String jsonString = getCapitalData(name);
			JSONObject jsonObject = new JSONObject(jsonString);

			String capital = jsonObject.getString("capital");
			System.out.println(name + " its capital is " + capital + ".");
			
			String region = jsonObject.getString("region");
			System.out.println(region);

			scanner.close();
			
			System.out.println("Thanks for using REST COUNTRIES.");

		}
		catch(JSONException e) {
			System.out.println(e.getMessage());
		}
		catch(IOException e){
			System.out.println(e.getMessage());
			
		}
		

	}
	
	public static String getCapitalData(String name) throws IOException{

		HttpURLConnection connection = (HttpURLConnection) new URL("https://restcountries.eu/#similar-projects/" + name).openConnection();
		
		connection.setRequestMethod("GET");

		int responseCode = connection.getResponseCode();
		if(responseCode == 200){
			String response = "";
			Scanner scanner = new Scanner(connection.getInputStream());
			while(scanner.hasNextLine()){
				response += scanner.nextLine();
				response += "\n";
			}
			System.out.println(response);
			scanner.close();

			return response;
		}
		
		// an error happened
		return null;
	}

}
